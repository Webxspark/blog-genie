import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { n as Sheet, o as SheetTrigger, p as SheetContent, q as SheetTitle, r as SheetHeader, R as ROUTES, I as Icon, A as AppLogo, T as TooltipProvider, s as Tooltip, t as TooltipTrigger, v as TooltipContent, B as Breadcrumbs, l as AppShell, m as AppContent } from "./breadcrumbs-YrlvjA52.js";
import { c as cn, B as Button, A as AppLogoIcon } from "./app-logo-icon-CoogQ1E6.js";
import * as NavigationMenuPrimitive from "@radix-ui/react-navigation-menu";
import { cva } from "class-variance-authority";
import { usePage, Link } from "@inertiajs/react";
import { Menu } from "lucide-react";
function NavigationMenu({
  className,
  children,
  viewport = true,
  ...props
}) {
  return /* @__PURE__ */ jsxs(
    NavigationMenuPrimitive.Root,
    {
      "data-slot": "navigation-menu",
      "data-viewport": viewport,
      className: cn(
        "group/navigation-menu relative flex max-w-max flex-1 items-center justify-center",
        className
      ),
      ...props,
      children: [
        children,
        viewport && /* @__PURE__ */ jsx(NavigationMenuViewport, {})
      ]
    }
  );
}
function NavigationMenuList({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    NavigationMenuPrimitive.List,
    {
      "data-slot": "navigation-menu-list",
      className: cn(
        "group flex flex-1 list-none items-center justify-center gap-1",
        className
      ),
      ...props
    }
  );
}
function NavigationMenuItem({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    NavigationMenuPrimitive.Item,
    {
      "data-slot": "navigation-menu-item",
      className: cn("relative", className),
      ...props
    }
  );
}
const navigationMenuTriggerStyle = cva(
  "group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground disabled:pointer-events-none disabled:opacity-50 data-[active=true]:bg-accent/50 data-[state=open]:bg-accent/50 data-[active=true]:text-accent-foreground ring-ring/10 dark:ring-ring/20 dark:outline-ring/40 outline-ring/50 transition-[color,box-shadow] focus-visible:ring-4 focus-visible:outline-1"
);
function NavigationMenuViewport({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: cn(
        "absolute top-full left-0 isolate z-50 flex justify-center"
      ),
      children: /* @__PURE__ */ jsx(
        NavigationMenuPrimitive.Viewport,
        {
          "data-slot": "navigation-menu-viewport",
          className: cn(
            "origin-top-center bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90 relative mt-1.5 h-[var(--radix-navigation-menu-viewport-height)] w-full overflow-hidden rounded-md border shadow md:w-[var(--radix-navigation-menu-viewport-width)]",
            className
          ),
          ...props
        }
      )
    }
  );
}
const mainNavItems = [
  {
    title: "Home",
    href: ROUTES.home
    // icon: LayoutGrid,
  },
  {
    title: "About",
    href: ROUTES.app.about
    // icon: LayoutGrid,
  },
  {
    title: "Contact Us",
    href: ROUTES.app.contact
    // icon: LayoutGrid,
  }
];
const rightNavItems = [];
const activeItemStyles = "text-neutral-900 dark:bg-neutral-800 dark:text-neutral-100";
function AppHeader({ breadcrumbs = [] }) {
  const page = usePage();
  const { auth } = page.props;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { className: "border-sidebar-border/80 border-b", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex h-16 items-center px-4 md:max-w-7xl", children: [
      /* @__PURE__ */ jsx("div", { className: "lg:hidden", children: /* @__PURE__ */ jsxs(Sheet, { children: [
        /* @__PURE__ */ jsx(SheetTrigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", className: "mr-2 h-[34px] w-[34px]", children: /* @__PURE__ */ jsx(Menu, { className: "h-5 w-5" }) }) }),
        /* @__PURE__ */ jsxs(SheetContent, { side: "left", className: "bg-sidebar flex h-full w-64 flex-col items-stretch justify-between", children: [
          /* @__PURE__ */ jsx(SheetTitle, { className: "sr-only", children: "Navigation Menu" }),
          /* @__PURE__ */ jsx(SheetHeader, { className: "flex justify-start text-left", children: /* @__PURE__ */ jsx(AppLogoIcon, { className: "h-6 w-6 fill-current text-black dark:text-white" }) }),
          /* @__PURE__ */ jsx("div", { className: "flex h-full flex-1 flex-col space-y-4 p-4", children: /* @__PURE__ */ jsxs("div", { className: "flex h-full flex-col justify-between text-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "flex flex-col space-y-4", children: mainNavItems.map((item) => /* @__PURE__ */ jsxs(Link, { href: item.href, className: "flex items-center space-x-2 font-medium", children: [
              item.icon && /* @__PURE__ */ jsx(Icon, { iconNode: item.icon, className: "h-5 w-5" }),
              /* @__PURE__ */ jsx("span", { children: item.title })
            ] }, item.title)) }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-col space-y-4", children: rightNavItems.map((item) => /* @__PURE__ */ jsxs(
              "a",
              {
                href: item.href,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "flex items-center space-x-2 font-medium",
                children: [
                  item.icon && /* @__PURE__ */ jsx(Icon, { iconNode: item.icon, className: "h-5 w-5" }),
                  /* @__PURE__ */ jsx("span", { children: item.title })
                ]
              },
              item.title
            )) })
          ] }) })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx(Link, { href: ROUTES.home, prefetch: true, className: "flex items-center space-x-2", children: /* @__PURE__ */ jsx(AppLogo, {}) }),
      /* @__PURE__ */ jsx("div", { className: "ml-6 hidden h-full items-center space-x-6 lg:flex", children: /* @__PURE__ */ jsx(NavigationMenu, { className: "flex h-full items-stretch", children: /* @__PURE__ */ jsx(NavigationMenuList, { className: "flex h-full items-stretch space-x-2", children: mainNavItems.map((item, index) => /* @__PURE__ */ jsxs(NavigationMenuItem, { className: "relative flex h-full items-center", children: [
        /* @__PURE__ */ jsxs(
          Link,
          {
            href: item.href,
            className: cn(
              navigationMenuTriggerStyle(),
              page.url === item.href && activeItemStyles,
              "h-9 cursor-pointer px-3"
            ),
            children: [
              item.icon && /* @__PURE__ */ jsx(Icon, { iconNode: item.icon, className: "mr-2 h-4 w-4" }),
              item.title
            ]
          }
        ),
        page.url === item.href && /* @__PURE__ */ jsx("div", { className: "absolute bottom-0 left-0 h-0.5 w-full translate-y-px bg-black dark:bg-white" })
      ] }, index)) }) }) }),
      /* @__PURE__ */ jsxs("div", { className: "ml-auto flex items-center space-x-2", children: [
        /* @__PURE__ */ jsx("div", { className: "relative flex items-center space-x-1", children: /* @__PURE__ */ jsx("div", { className: "hidden lg:flex", children: rightNavItems.map((item) => /* @__PURE__ */ jsx(TooltipProvider, { delayDuration: 0, children: /* @__PURE__ */ jsxs(Tooltip, { children: [
          /* @__PURE__ */ jsx(TooltipTrigger, { children: /* @__PURE__ */ jsxs(
            "a",
            {
              href: item.href,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "group text-accent-foreground ring-offset-background hover:bg-accent hover:text-accent-foreground focus-visible:ring-ring ml-1 inline-flex h-9 w-9 items-center justify-center rounded-md bg-transparent p-0 text-sm font-medium transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsx("span", { className: "sr-only", children: item.title }),
                item.icon && /* @__PURE__ */ jsx(Icon, { iconNode: item.icon, className: "size-5 opacity-80 group-hover:opacity-100" })
              ]
            }
          ) }),
          /* @__PURE__ */ jsx(TooltipContent, { children: /* @__PURE__ */ jsx("p", { children: item.title }) })
        ] }) }, item.title)) }) }),
        auth.user ? /* @__PURE__ */ jsx(
          Link,
          {
            href: route("dashboard"),
            className: "inline-block rounded-sm border border-[#19140035] px-5 py-1.5 text-sm leading-normal text-[#1b1b18] hover:border-[#1915014a] dark:border-[#3E3E3A] dark:text-[#EDEDEC] dark:hover:border-[#62605b]",
            children: "Dashboard"
          }
        ) : /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(
          Link,
          {
            href: route("login"),
            className: "inline-block rounded-sm border border-transparent px-5 py-1.5 text-sm leading-normal text-[#1b1b18] hover:border-[#19140035] dark:text-[#EDEDEC] dark:hover:border-[#3E3E3A]",
            children: "Log in"
          }
        ) })
      ] })
    ] }) }),
    breadcrumbs.length > 1 && /* @__PURE__ */ jsx("div", { className: "border-sidebar-border/70 flex w-full border-b", children: /* @__PURE__ */ jsx("div", { className: "mx-auto flex h-12 w-full items-center justify-start px-4 text-neutral-500 md:max-w-7xl", children: /* @__PURE__ */ jsx(Breadcrumbs, { breadcrumbs }) }) })
  ] });
}
function AppHeaderLayout({ children, breadcrumbs }) {
  return /* @__PURE__ */ jsxs(AppShell, { children: [
    /* @__PURE__ */ jsx(AppHeader, { breadcrumbs }),
    /* @__PURE__ */ jsx(AppContent, { children })
  ] });
}
export {
  AppHeaderLayout as A
};
