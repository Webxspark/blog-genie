import { jsxs, jsx } from "react/jsx-runtime";
import { usePage, Head } from "@inertiajs/react";
import { A as AppHeaderLayout } from "./app-header-layout-TROUh8cF.js";
import { R as ROUTES } from "./breadcrumbs-YrlvjA52.js";
import dayjs from "dayjs";
import "./app-logo-icon-CoogQ1E6.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-navigation-menu";
import "lucide-react";
import "react";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
const appName = "SparkleAI";
const PostPreview = () => {
  const { post } = usePage().props;
  console.log(post);
  return /* @__PURE__ */ jsxs(AppHeaderLayout, { breadcrumbs: [
    {
      title: "Home",
      href: ROUTES.home
    },
    {
      title: "Post",
      href: "/"
    }
  ], children: [
    /* @__PURE__ */ jsxs(Head, { children: [
      /* @__PURE__ */ jsx("title", { children: post.title }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: post.description }),
      /* @__PURE__ */ jsx("meta", { property: "og:title", content: post.title }),
      /* @__PURE__ */ jsx("meta", { property: "og:description", content: post.description }),
      /* @__PURE__ */ jsx("meta", { property: "og:image", content: `/images/${post.thumbnail}` }),
      /* @__PURE__ */ jsx("meta", { property: "og:url", content: location.href }),
      /* @__PURE__ */ jsx("meta", { property: "og:type", content: "article" }),
      /* @__PURE__ */ jsx("meta", { property: "og:site_name", content: appName }),
      /* @__PURE__ */ jsx("meta", { property: "og:locale", content: "en_US" }),
      /* @__PURE__ */ jsx("meta", { property: "article:published_time", content: post.created_at }),
      /* @__PURE__ */ jsx("meta", { property: "article:modified_time", content: post.updated_at }),
      /* @__PURE__ */ jsx("meta", { property: "article:author", content: post.user.name }),
      /* @__PURE__ */ jsx("meta", { property: "article:publisher", content: post.user.name }),
      /* @__PURE__ */ jsx("meta", { property: "article:published", content: post.created_at }),
      /* @__PURE__ */ jsx("meta", { property: "article:modified", content: post.updated_at })
    ] }),
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
      "div",
      {
        className: "pt-8 pb-16 lg:pt-16 lg:pb-24  antialiased",
        children: /* @__PURE__ */ jsx("div", { className: "flex justify-between px-4 mx-auto max-w-screen-xl", children: /* @__PURE__ */ jsxs(
          "article",
          {
            className: "mx-auto w-full max-w-2xl format format-sm sm:format-base lg:format-lg format-blue dark:format-invert",
            children: [
              /* @__PURE__ */ jsxs("header", { className: "mb-4 lg:mb-6 not-format", children: [
                /* @__PURE__ */ jsx("address", { className: "flex items-center mb-6 not-italic", children: /* @__PURE__ */ jsxs(
                  "div",
                  {
                    className: "inline-flex items-center mr-3 text-sm text-gray-900 dark:text-white",
                    children: [
                      /* @__PURE__ */ jsx(
                        "img",
                        {
                          className: "mr-4 w-16 h-16 rounded-full",
                          src: "https://github.com/shadcn.png",
                          alt: post.user.name
                        }
                      ),
                      /* @__PURE__ */ jsxs("div", { children: [
                        /* @__PURE__ */ jsx(
                          "a",
                          {
                            href: "#",
                            rel: "author",
                            className: "text-xl font-bold text-gray-900 dark:text-white",
                            children: post.user.name
                          }
                        ),
                        /* @__PURE__ */ jsx("p", { className: "text-base text-gray-500 dark:text-gray-400", children: /* @__PURE__ */ jsx(
                          "time",
                          {
                            dateTime: dayjs(post.created_at).format("YYYY-MM-DD hh:mm:ss A"),
                            title: dayjs(post.created_at).format("MMMM DD, YYYY"),
                            children: dayjs(post.created_at).format("MMM. DD, YYYY")
                          }
                        ) })
                      ] })
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsx("h1", { className: "mb-4 text-3xl font-extrabold leading-tight text-gray-900 lg:mb-6 lg:text-4xl dark:text-white", children: post.title })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "lead", children: post.description }),
              /* @__PURE__ */ jsx("figure", { className: "my-4", children: /* @__PURE__ */ jsx(
                "img",
                {
                  src: `/images/${post.thumbnail}`,
                  className: "w-full h-96 object-cover rounded-lg",
                  alt: post.title
                }
              ) }),
              /* @__PURE__ */ jsx(
                "div",
                {
                  className: "prose dark:prose-invert",
                  dangerouslySetInnerHTML: { __html: post.body }
                }
              )
            ]
          }
        ) })
      }
    ) })
  ] });
};
export {
  PostPreview as default
};
