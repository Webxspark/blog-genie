import { jsx, jsxs } from "react/jsx-runtime";
import { A as AppLayout } from "./app-layout-gkd8VEFr.js";
import { R as ROUTES } from "./breadcrumbs-YrlvjA52.js";
import { usePage, Head, router } from "@inertiajs/react";
import { c as cn, B as Button } from "./app-logo-icon-CoogQ1E6.js";
import { PlusSquare, Eye, Edit, Trash2 } from "lucide-react";
import dayjs from "dayjs";
import { Modal } from "antd";
import { toast } from "sonner";
import "@ant-design/v5-patch-for-react-19";
import { useEffect } from "react";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
import "clsx";
import "tailwind-merge";
function Table({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "table-container",
      className: "relative w-full overflow-x-auto",
      children: /* @__PURE__ */ jsx(
        "table",
        {
          "data-slot": "table",
          className: cn("w-full caption-bottom text-sm", className),
          ...props
        }
      )
    }
  );
}
function TableBody({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "tbody",
    {
      "data-slot": "table-body",
      className: cn("[&_tr:last-child]:border-0", className),
      ...props
    }
  );
}
function TableRow({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "tr",
    {
      "data-slot": "table-row",
      className: cn(
        "hover:bg-muted/50 data-[state=selected]:bg-muted border-b transition-colors",
        className
      ),
      ...props
    }
  );
}
function TableHead({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "th",
    {
      "data-slot": "table-head",
      className: cn(
        "text-foreground h-10 px-2 text-left align-middle font-medium whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
        className
      ),
      ...props
    }
  );
}
function TableCell({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "td",
    {
      "data-slot": "table-cell",
      className: cn(
        "p-2 align-middle whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
        className
      ),
      ...props
    }
  );
}
const breadcrumbs = [
  {
    title: "Dashboard",
    href: ROUTES.dashboard
  },
  {
    title: "Posts",
    href: ROUTES.posts.index
  }
];
const Posts = () => {
  const { posts, flash } = usePage().props;
  useEffect(() => {
    if (flash == null ? void 0 : flash.success) {
      toast.success(flash == null ? void 0 : flash.success);
    }
    if (flash == null ? void 0 : flash.error) {
      toast.error(flash == null ? void 0 : flash.error);
    }
  }, [flash]);
  const handleDeleteRequest = (id) => {
    Modal.confirm({
      title: "Are you sure to delete this post?",
      content: "This action cannot be undone.",
      okText: "Delete",
      okType: "danger",
      cancelText: "Cancel",
      onOk: () => {
        router.delete(`${ROUTES.posts.index}/${id}`, {
          onSuccess: () => {
            router.reload();
          },
          onError: (error) => {
            console.log(error);
          }
        });
      }
    });
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsxs(Head, { children: [
      /* @__PURE__ */ jsx("title", { children: "My Posts" }),
      /* @__PURE__ */ jsx("meta", { name: "description", content: "My Posts" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex h-full flex-1 flex-col gap-4 rounded-xl p-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-gray-900 dark:text-gray-100", children: "My Posts" }),
        /* @__PURE__ */ jsxs(Button, { onClick: () => router.visit(ROUTES.posts.create), children: [
          /* @__PURE__ */ jsx(PlusSquare, {}),
          " New Post"
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Table, { children: [
        /* @__PURE__ */ jsxs(TableRow, { children: [
          /* @__PURE__ */ jsx(TableHead, { className: "w-20", children: "S.No" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Title" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Views" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Uploaded On" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Actions" })
        ] }),
        /* @__PURE__ */ jsx(TableBody, { children: posts.map((post, index) => /* @__PURE__ */ jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxs(TableCell, { children: [
            index + 1,
            ")"
          ] }),
          /* @__PURE__ */ jsx(TableCell, { children: post.title }),
          /* @__PURE__ */ jsxs(TableCell, { className: "flex h-full items-center gap-2", children: [
            /* @__PURE__ */ jsx(
              Eye,
              {
                className: "size-4"
              }
            ),
            " ",
            post.views
          ] }),
          /* @__PURE__ */ jsx(TableCell, { children: dayjs(post.created_at).format("DD MMM YYYY (hh:mm A)") }),
          /* @__PURE__ */ jsxs(TableCell, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Button, { onClick: () => router.visit(`${ROUTES.posts.index}/${post.id}/edit`), size: null, variant: "ghost", className: "px-2 p-1", children: /* @__PURE__ */ jsx(Edit, {}) }),
            /* @__PURE__ */ jsx(
              Button,
              {
                onClick: () => handleDeleteRequest(post.id),
                size: null,
                variant: "destructive",
                className: "p-1 px-2",
                children: /* @__PURE__ */ jsx(Trash2, {})
              }
            )
          ] })
        ] }, index)) })
      ] })
    ] })
  ] });
};
export {
  Posts as default
};
