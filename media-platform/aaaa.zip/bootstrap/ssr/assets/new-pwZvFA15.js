import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useRef, useEffect } from "react";
import { A as AppLayout } from "./app-layout-gkd8VEFr.js";
import { usePage, Head, router } from "@inertiajs/react";
import { L as Label, I as Input } from "./label-gNW90GOR.js";
import { c as cn, B as Button } from "./app-logo-icon-CoogQ1E6.js";
import { R as ROUTES } from "./breadcrumbs-YrlvjA52.js";
import FroalaEditorComponent from "react-froala-wysiwyg";
import "froala-editor/js/plugins.pkgd.min.js";
import { LoaderCircle, Loader, Send } from "lucide-react";
import { toast } from "sonner";
import "@radix-ui/react-dropdown-menu";
import "@radix-ui/react-avatar";
import "@radix-ui/react-label";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
function Textarea({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "textarea",
    {
      "data-slot": "textarea",
      className: cn(
        "border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        className
      ),
      ...props
    }
  );
}
const New = () => {
  const { post } = usePage().props;
  const [initialContent, setInitialContent] = useState("");
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [thumbnail, setThumbnail] = useState(null);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const isMounted = useRef(false);
  const [editorLoaded, setEditorLoaded] = useState(false);
  const breadcrumbs = [
    {
      title: "My Posts",
      href: ROUTES.posts.index
    },
    {
      title: post ? "Edit" : "New",
      href: ROUTES.posts.create
    }
  ];
  useEffect(() => {
    if (!isMounted.current) {
      isMounted.current = true;
      if (post) {
        setTitle(post.title);
        setDescription(post.description);
        setInitialContent(post.body);
        setContent(post.body);
        setThumbnail(post.thumbnail);
      }
      setTimeout(() => {
        setEditorLoaded(true);
      }, 500);
    }
  }, [post]);
  const handleFormSubmit = (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append("title", title);
    data.append("description", description);
    data.append("body", content);
    if (thumbnail instanceof File) {
      data.append("thumbnail", thumbnail);
    }
    const reqOptions = {
      onBefore: () => {
        setLoading(true);
        setErrors({});
      },
      onSuccess: () => {
        router.visit(ROUTES.posts.index);
      },
      onError: (validationErrors) => {
        toast.error("Oops! One or more field(s) are invalid.");
        console.log(errors || "Something went wrong! :(");
        setErrors(validationErrors);
      },
      onFinish: () => {
        setLoading(false);
      }
    };
    if (!post) {
      router.post(ROUTES.posts.index, data, reqOptions);
    } else {
      router.post(`${ROUTES.posts.index}/${post.id}`, {
        _method: "PUT",
        title,
        description,
        body: content,
        ...thumbnail instanceof File ? { thumbnail } : {}
      }, reqOptions);
    }
  };
  return /* @__PURE__ */ jsxs(AppLayout, { breadcrumbs, children: [
    /* @__PURE__ */ jsx(Head, { title: "New Post" }),
    /* @__PURE__ */ jsxs("div", { className: "flex h-full flex-1 flex-col gap-4 rounded-xl p-4", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-gray-900 dark:text-gray-100", children: "New Post" }),
      /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center", children: /* @__PURE__ */ jsxs(
        "form",
        {
          onSubmit: handleFormSubmit,
          className: "space-y-4 w-full  border dark:border-gray-600 p-4 rounded-sm shadow-2xl border-gray-800",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "title", children: "Title" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "title",
                  type: "text",
                  value: title,
                  name: "title",
                  onChange: (e) => setTitle(e.target.value),
                  maxLength: 250,
                  placeholder: "Ex: My first post"
                }
              ),
              errors.title && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-sm", children: errors.title })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "description", children: "Description" }),
              /* @__PURE__ */ jsx(
                Textarea,
                {
                  id: "description",
                  value: description,
                  name: "description",
                  onChange: (e) => setDescription(e.target.value),
                  className: "resize-none",
                  placeholder: "Ex: This is my first post"
                }
              ),
              errors.description && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-sm", children: errors.description })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "thumbnail", children: "Thumbnail" }),
              post && /* @__PURE__ */ jsx(
                "img",
                {
                  src: `/images/${post.thumbnail}`,
                  alt: post.title,
                  className: "w-32 h-32 object-cover rounded-md"
                }
              ),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "thumbnail",
                  type: "file",
                  name: "thumbnail",
                  onChange: (e) => {
                    var _a;
                    const file = ((_a = e.target.files) == null ? void 0 : _a[0]) || null;
                    setThumbnail(file);
                  },
                  accept: "image/*"
                }
              ),
              errors.thumbnail && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-sm", children: errors.thumbnail })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "body", children: "Content" }),
              errors.body && /* @__PURE__ */ jsx("p", { className: "text-red-500 text-sm", children: errors.body }),
              editorLoaded && /* @__PURE__ */ jsx(
                FroalaEditorComponent,
                {
                  tag: "textarea",
                  model: initialContent,
                  config: {
                    theme: "royal",
                    key: "1C%kZV[IX)_SL}UJHAEFZMUJOYGYQE[\\ZJ]RAe(+%$==",
                    editorClass: "prose max-w-none",
                    attribution: false,
                    documentReady: true,
                    plugins: ["link", "spellCheck", "inlineStyle", "charCounter"],
                    toolbarButtons: [
                      ["fullscreen", "undo", "redo"],
                      ["bold", "italic", "underline"],
                      ["fontFamily", "fontSize"],
                      ["paragraphFormat", "align"],
                      ["color", "insertLink"],
                      ["quote", "insertHR"]
                    ],
                    events: {
                      "contentChanged": function() {
                        const newContent = this.html.get();
                        setContent(newContent);
                      }
                    },
                    model: content
                  }
                }
              ) || /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(LoaderCircle, { className: "animate-spin" }) })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center justify-end", children: /* @__PURE__ */ jsxs(Button, { disabled: loading, children: [
              loading && /* @__PURE__ */ jsx(Loader, { className: "animate-spin" }) || /* @__PURE__ */ jsx(Send, {}),
              " ",
              post ? "Update" : "Publish"
            ] }) })
          ]
        }
      ) })
    ] })
  ] });
};
export {
  New as default
};
