import { jsx, jsxs } from "react/jsx-runtime";
import { A as AppHeaderLayout } from "./app-header-layout-TROUh8cF.js";
import { usePage, Head, router, Link } from "@inertiajs/react";
import { c as cn } from "./app-logo-icon-CoogQ1E6.js";
import { R as ROUTES } from "./breadcrumbs-YrlvjA52.js";
import { UserCircle } from "lucide-react";
import "@radix-ui/react-navigation-menu";
import "class-variance-authority";
import "@radix-ui/react-slot";
import "clsx";
import "tailwind-merge";
import "react";
import "@radix-ui/react-dialog";
import "@radix-ui/react-tooltip";
function Card({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "card",
      className: cn(
        "bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",
        className
      ),
      ...props
    }
  );
}
function CardTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "card-title",
      className: cn("leading-none font-semibold", className),
      ...props
    }
  );
}
function CardDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "card-description",
      className: cn("text-muted-foreground text-sm", className),
      ...props
    }
  );
}
function CardContent({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "card-content",
      className: cn("px-6", className),
      ...props
    }
  );
}
const BlogApp = () => {
  const { posts } = usePage().props;
  console.log(posts);
  return /* @__PURE__ */ jsxs(AppHeaderLayout, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Home" }),
    /* @__PURE__ */ jsxs("div", { className: "py-7 lg:px-0", children: [
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3", children: posts.length > 0 && posts.map((post) => /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { children: [
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "border-sidebar-border/70 dark:border-sidebar-border relative aspect-video overflow-hidden rounded-xl border",
            children: /* @__PURE__ */ jsx(
              "img",
              {
                src: `/images/${post.thumbnail}`,
                alt: post.title,
                className: "w-full h-full object-cover cursor-pointer",
                onClick: () => router.visit(`${ROUTES.app.post}/${post.slug}`)
              }
            )
          },
          post.id
        ),
        /* @__PURE__ */ jsxs("div", { className: "pt-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 my-1", children: [
            /* @__PURE__ */ jsx(
              UserCircle,
              {
                className: "size-5"
              }
            ),
            " ",
            post.user.name
          ] }),
          /* @__PURE__ */ jsxs(Link, { href: `${ROUTES.app.post}/${post.slug}`, children: [
            /* @__PURE__ */ jsx(CardTitle, { className: "py-1.5 leading-5", children: post.title }),
            /* @__PURE__ */ jsxs(CardDescription, { children: [
              post.description.slice(0, 100),
              "..."
            ] })
          ] })
        ] })
      ] }) })) }),
      posts.length === 0 && /* @__PURE__ */ jsx("div", { className: "flex items-center h-[40dvh] justify-center", children: /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold text-gray-900 dark:text-gray-100", children: "No Posts Found" }) })
    ] })
  ] });
};
export {
  BlogApp as default
};
